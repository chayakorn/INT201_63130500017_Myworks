export let product = [{
        id: 1,
        img: "krapao.jpg",
        nameEng: "KrapaoMooHotButFreeze",
        name: "กะเพราหมูร้อนๆแช่แข็ง",
        price: 55,
        description: "กระเพราร้อนๆที่นำเข้าไมโครเวฟแล้วกินได้ทันที อร่อยไม่ซ้ำเพราะจำสูตรไม่ได้ :)",
        stock: 38
    },
    {
        id: 2,
        img: "suki.jpg",
        nameEng: "SukiHotButFreeze",
        name: "สุกี้ร้อนๆแช่แข็ง",
        price: 60,
        description: "สุกี้ร้อนๆจากเกาะกวางตุ้ง กินแล้วลอยได้ อร่อยไม่ซ้ำเพราะจำสูตรไม่ได้เหมือนกัน :)",
        stock: 21
    },
    {
        id: 3,
        img: "kaopad.jpg",
        nameEng: "KaoPadHotButFreeze",
        name: "ข้าวผัดร้อนๆแช่แข็ง",
        price: 40,
        description: "ข้าวผัดจากไข่สดๆจากแม่ไก่ อร่อยไม่ซ้ำเพราะจำสูตรไม่ได้เหมือนกัน :)",
        stock: 8
    },
    {
        id: 4,
        img: "kaijeaw.jpg",
        nameEng: "KaiJeawHotButFreeze",
        name: "ไข่เจียวร้อนๆแช่แข็ง",
        price: 1000,
        description: "ไข่เจียวจากพี่เจสุดหล่อ อร่อยไม่ซ้ำเพราะจำสูตรไม่ได้เหมือนกัน :)",
        stock: 2
    },
    {
        id: 5,
        img: "ithemtord.jpg",
        nameEng: "IthemTordHotButFreeze",
        name: "ไอติมทอดร้อนๆแช่แข็ง",
        price: 25,
        description: "ไอติมทอดจากตู้เย็น กินไม่หมดเลยเอามาขาย อร่อยไม่ซ้ำเพราะจำสูตรไม่ได้เหมือนกัน :)",
        stock: 48
    },
    {
        id: 6,
        img: "water.jpg",
        nameEng: "WarmWaterButFreeze",
        name: "น้ำปล่าวอุ่นๆแช่แข็ง",
        price: 10,
        description: "น้ำอุ่นๆแช่แข็งจากตู้เย็น น้ำไม่ผิด น้ำปล่าว :)",
        stock: 20
    }
]