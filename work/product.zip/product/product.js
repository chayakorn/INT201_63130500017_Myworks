export let products = [{
        img: "กระเพรา.jpg",
        id: 1,
        name: "กระเพรา",
        desc: "sdfjalskdfj",
        price: 55,
        stock: 38
    },
    {
        img: "สุกี้.jpg",
        id: 2,
        name: "สุกี้",
        desc: "sdfjalskdfj",
        price: 60,
        stock: 21
    },
]