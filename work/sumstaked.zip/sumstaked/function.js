export function sumStaked(str = 'hello') {
    return (str1) => { str += ` ${str1}`; return str }
}