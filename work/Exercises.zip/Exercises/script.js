document.querySelector(".group3").textContent = "HBD ผมด้วย ,ผมเกิดเมื่อวาน ";
document.querySelector(".group3").innerHTML += "<b>เย้</b>"